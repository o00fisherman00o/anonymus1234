var perfEntries = performance.getEntriesByType("navigation");

if (perfEntries[0].type === "back_forward") {
    window.location.reload();
}
var winwidth = 0;
window.onresize = function(event) {
    winwidth = $(window).width();
}
var a = 2;

//var winwidth = $(window).width();

$(window).bind("beforeunload", function() {
    $.ajax({
        url: "/logout",
        data: { "info": "timeout" },
        type: "POST",
        success: function(response) {
            console.log(response['state']);

        }
    })
})

$("#hamburger-lg").click(function() {
    console.log(winwidth);
    if (winwidth > 768) {

        if (a % 2 === 0) {
            $("#menu").css({ "width": "5%" });
            $("#inner-workspace").css({ "left": "5%", "width": "95%" });
        } else {
            $("#menu").css({ "width": "15%" });
            $("#inner-workspace").css({ "left": "15%", "width": "85%" });
        }
        a += 1;
    }
    if (winwidth <= 768) {

        if (a % 2 === 0) {
            $("#menu").css({ "width": "260px", "z-index": "2" });

        } else {
            $("#menu").css({ "width": "0%", "z-index": "1" });
        }
        a += 1;
    }
});

$("#rest").click(function() {
    if (winwidth <= 768) {
        $("#menu").css({ "width": "0%", "z-index": "1" });
    }
})

$("#menu").hover(function() {
        if (a % 2 != 0) {
            $(this).css({ "width": "15%", "z-index": "2" });
        }
    },
    function() {
        if (a % 2 != 0) {
            $(this).css({ "width": "5%", "z-index": "1" });
        }
    });

$("#logout").click(function() {
    $.ajax({
        url: "/logout",
        data: { "info": "logout" },
        type: 'POST',
        success: function(response) {
            msg = response['msg'];
            if (msg === "loggedout") {
                window.location.href = "/owner";
            } else if (msg === "home") {
                window.location.href = "/dashboard";
            } else {
                console.log(msg)
            }
        },
        error: function() {
            console.log("some error");
        }
    })
})