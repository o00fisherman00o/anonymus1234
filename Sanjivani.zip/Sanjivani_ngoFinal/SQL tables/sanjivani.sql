-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 28, 2021 at 07:50 PM
-- Server version: 8.0.21
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sanjivani`
--

-- --------------------------------------------------------

--
-- Table structure for table `privellage`
--

DROP TABLE IF EXISTS `privellage`;
CREATE TABLE IF NOT EXISTS `privellage` (
  `id` int NOT NULL AUTO_INCREMENT,
  `privellage` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `privellage`
--

INSERT INTO `privellage` (`id`, `privellage`) VALUES
(1, 'president'),
(2, 'vice-president'),
(3, 'team member');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `first_name` varchar(128) NOT NULL,
  `last_name` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `date_joined` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `phone` varchar(13) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `first_name`, `last_name`, `email`, `password`, `last_login`, `date_joined`, `is_active`, `phone`) VALUES
(1, 'priyojit_123', 'Priyojit', 'Chakarborty', 'priyojit@gmail.com', '4c4bd54fbed68c5523a25badd6c7ed9b', NULL, '2021-11-01 15:54:12', 0, '+917524914220'),
(2, 'Harsh_123', 'Harsh', 'Yadav', 'harsh@gmail.com', '789f215f55165cb68d8cd7d1ac2868a7', NULL, '2021-11-01 16:48:04', 0, '+917524914220');

-- --------------------------------------------------------

--
-- Table structure for table `user_privellage`
--

DROP TABLE IF EXISTS `user_privellage`;
CREATE TABLE IF NOT EXISTS `user_privellage` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `privellage_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `privellage_id` (`privellage_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_privellage`
--

INSERT INTO `user_privellage` (`id`, `user_id`, `privellage_id`) VALUES
(1, 1, 1),
(2, 2, 3);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_privellage`
--
ALTER TABLE `user_privellage`
  ADD CONSTRAINT `user_privellage_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `user_privellage_ibfk_2` FOREIGN KEY (`privellage_id`) REFERENCES `privellage` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
