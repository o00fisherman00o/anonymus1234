var perfEntries = performance.getEntriesByType("navigation");

if (perfEntries[0].type === "back_forward") {
    window.location.reload();
}
$(window).on("load", function() {
    $("#loader-box").delay(1000).fadeOut(1000);
    $("#page").delay(1000).fadeIn(1000);
    var userStatus = $("#user-statusCheck").text();
    if (userStatus === 'loggedin') {
        $("#login").css({ "display": "none" });
        $(".user").css({ "display": "flex" });
    } else if (userStatus === 'loggedout') {
        $("#login").css({ "display": "block" });
        $(".user").css({ "display": "none" });

    }
    var slides = parseInt($("#slides").text());
    var cards = parseInt($('#cards').text());
    var title = $('#title').text().replace('[', '');
    title = title.replace(']', '');
    title = title.split(",");
    var fund = $("#fund").text().replace('[', '');
    fund = fund.replace(']', '');
    fund = fund.split(',');
    var support = $("#supporters").text().replace('[', '');
    support = support.replace(']', '');
    support = support.split(',');
    var percent = $("#percent").text().replace('[', '');
    percent = percent.replace(']', '');
    percent = percent.split(',');
    var urgency = $("#urgency").text().replace('[', '');
    urgency = urgency.replace(']', '');
    urgency = urgency.replace(' ', '');
    urgency = urgency.split(',');
    var tax = $("#tax_Benifit").text().replace('[', '');
    tax = tax.replace(']', '');
    tax = tax.replace(' ', '');
    tax = tax.split(',');


    var cardIm = $("#cardImage").text().replace('[', '');
    cardIm = cardIm.replace(']', '');
    cardIm = cardIm.replace(/[ '']/g, '');
    cardIm = cardIm.split(',');

    var pos = 0;
    var palleteNo = parseInt($("#palleteNo").text());

    var portfolioTitle = $("#portfolioTitle").text().replace('[', '');
    portfolioTitle = portfolioTitle.replace(']', '');
    portfolioTitle = portfolioTitle.replace(/['']/g, '');
    portfolioTitle = portfolioTitle.split(',');
    var portfolioImage = $("#portfolioImage").text().replace('[', '');
    portfolioImage = portfolioImage.replace(']', '');
    portfolioImage = portfolioImage.replace(/[ '']/g, '');
    portfolioImage = portfolioImage.split(',');
    var badge = $("#badge").text().replace('[', '');
    badge = badge.replace(']', '');
    badge = badge.replace(/[ '']/g, '');
    badge = badge.split(',');
    var successTitle = $("#successTitle").text().replace('[', '');
    successTitle = successTitle.replace(']', '');
    successTitle = successTitle.replace(/['']/g, '');
    successTitle = successTitle.split(',');
    var successContent = $("#successContent").text().replace('[', '');
    successContent = successContent.replace(']', '');
    successContent = successContent.replace(/['']/g, '');
    successContent = successContent.split(',');
    var successImage = $("#successImage").text().replace('[', '');
    successImage = successImage.replace(']', '');
    successImage = successImage.replace(/[ '']/g, '');
    successImage = successImage.split(',');
    var successNumber = parseInt($("#successNumber").text());



    for (let i = 0; i < slides; i++) {
        if (i === 0) {

            $(".carousel-indicators").append(" <button style='height:20px; width: 20px; background-color: red; border-radius: 50%;' type='button' data-bs-target='#carouselExampleIndicators' data-bs-slide-to='" + i + "' class='active' aria-current='true' aria-label='Slide " + (i + 1) + "'></button>");
            $(".carousel-inner").append("<div class='carousel-item active'><img id='carousel-image' src='/static/CSS/images/carousel/slide" + i + ".jpg' class='d-block w-100 img-fluid' alt='...'></div>");
        } else {

            $(".carousel-indicators").append("<button style='height:20px; width: 20px; background-color: rgb(111, 0, 255); border-radius: 50%;' type='button' data-bs-target='#carouselExampleIndicators' data-bs-slide-to='" + i + "' aria-label='Slide " + (i + 1) + "'></button>");
            $(".carousel-inner").append("<div class='carousel-item'><img id='carousel-image' src='/static/CSS/images/carousel/slide" + i + ".jpg' class='d-block w-100 img-fluid' alt='...'></div>");
        }

    }
    for (let i = 0; i < cards; i++) {
        var urgent = "";
        var t = 0.0;
        var taxBenifit = "";
        console.log(tax[i]);
        if (cardIm[i] === "None") {
            cardIm[i] = "no_image.png";
        }


        if (urgency[i] === "0" || urgency[i] === " 0") {
            urgent = "none";
        } else {
            urgent = "block";
        }
        if (tax[i] === "0" || tax[i] === " 0") {
            taxBenifit = "none";
        } else {
            taxBenifit = "block";
        }


        fund[i] = fund[i].replace(' ', '');
        if (fund[i].length >= 7) {

            t = parseFloat(fund[i]) / 100000;
            t = t.toFixed(1);

            fund[i] = (t.toString() + "lac");

        } else if (fund[i].length >= 5) {

            t = parseFloat(fund[i]) / 1000;
            t = t.toFixed(1);

            fund[i] = (t.toString() + "K");

        }

        var query = "<div style='left:" + pos + "rem' class='card'><span style='display:" + taxBenifit + ";' id='tax-benifit' >TAX BENIFIT</span><span style='display:" + urgent + ";' id='urgent' >URGENT</span><img style=' border-image: linear-gradient(to left, #ccc " + (100 - percent[i]) + "%, #2279ca " + percent[i] + "%) 2;' id='card-img' src='/static/CSS/images/donations/" + cardIm[i] + "' class='card-img-top' alt='...'><div class='card-body'><h6 class='card-title'>" + title[i].substring(0, 30) + ". . .</h6><p class='card-text'>By <a href=''>Sanjivani NGO.</a></p><table class='table'><thead><tr><th>" + fund[i] + "</th><th>" + support[i] + "</th><th onclick=share(" + (i + 1) + ") id='share'><i class='fas fa-share'></i></th></tr></thead><tbody><tr><td>Fund</td><td>Supporters</td><td value=" + (i + 1) + " onclick=share(" + (i + 1) + ") id='share'" +
            ">Share</td></tr></tbody></table><div class='d-grid gap-2'><form action='/donate' method='GET'><button value=" + (i + 1) + " name='donate' type='submit' class='btn btn-primary'>Donate Now</button></form></div></div></div>"
        $("#card-holder").append(query);
        pos = pos + 20;
    }

    for (let i = 0; i < palleteNo; i++) {
        if (portfolioImage[i] === 'None') {
            portfolioImage[i] = 'no_image.png';
        }
        $("#pallete-holder").append("<div name='" + portfolioTitle[i] + "' id='pallete'><img id='pallete-img' src='/static/CSS/images/portfolio/pallete/" + portfolioImage[i] + "' class='card-img-top img-fluid' alt='...'><div id='badge-bg'><img id='badge' src='/static/CSS/images/portfolio/badge/" + badge[i] + ".png' class='img-fluid' alt='...'></div><div id='pallete-body'><p>" + portfolioTitle[i] + "</p></div></div>");
    }
    for (let i = 0; i < successNumber; i++) {
        console.log(successImage[i]);
        $("#success-slide").append("<div id='stories'><div class='story-img'><img class='img-fluid' src='/static/CSS/images/success_stories/" + successImage[i] + "'></div><div class='story-text'><h3>" + successTitle[i] + "</h3><p>" + successContent[i] + "</p><h6 id='readMore' value=''>Read more</h6></div></div>")
    }



})
$("#options-myodoc>.col>img").click(function() {
    var a = "";
    a = $(this).attr("value");
    $("#button-myodoc>button").attr("value", a);
    if (a.localeCompare("Celebrations") == 0) {
        $("#inHonourOf").css({ "background-color": "transparent" });
        $("#celebrations").css({ "background-color": "#86c540" });

        $("#inMemoryOf").css({ "background-color": "transparent" });
    }

    if (a.localeCompare("In Honour of") == 0) {

        $("#inHonourOf").css({ "background-color": "#86c540" });
        $("#celebrations").css({ "background-color": "transparent" });

        $("#inMemoryOf").css({ "background-color": "transparent" });
    }
    if (a.localeCompare("In Memory of") == 0) {
        $("#celebrations").css({ "background-color": "transparent" });
        $("#inHonourOf").css({ "background-color": "transparent" });
        $("#inMemoryOf").css({ "background-color": "#86c540" });
    }
})
$("#button-myodoc>button").click(function() {
    console.log($(this).attr("value"));
})


function isIntoView(elem) {
    var documentViewTop = $(window).scrollTop();
    var documentViewBottom = documentViewTop + $(window).height();

    var elementTop = $(elem).offset().top;
    var elementBottom = elementTop + $(elem).height();

    return ((elementBottom <= documentViewBottom) && (elementTop >= documentViewTop));
}
$(window).on("scroll", function() {
    if (isIntoView($('#container-analysis'))) {

        var i = 190000000;
        var j = 1600000;
        var k = 71000;
        var l = 160000000;
        var m = 9900000;
        setInterval(function() {
            if (i > 200000000) {
                clearInterval();
            } else {
                $("#rf").text(alphanum(i));
                i = i + 10000;
            }
        }, 0.005)
        setInterval(function() {
            if (j > 1700000) {
                clearInterval();
            } else {
                $("#hk").text(alphanum(j));
                j = j + 100;
            }
        }, 0.005)
        setInterval(function() {
            if (k > 72000) {
                clearInterval();
            } else {
                $("#fk").text(alphanum(k));
                k = k + 1;
            }
        }, 0.005)
        setInterval(function() {
            if (l > 170000000) {
                clearInterval();
            } else {
                $("#mdm").text(alphanum(l));
                l = l + 10000;
            }
        }, 0.005)
        setInterval(function() {
            if (m > 10000000) {
                clearInterval();
            } else {
                $("#am").text(alphanum(m));
                m = m + 100;
            }
        }, 0.005)

        // part 2
        function alphanum(nnum) {
            if (nnum > 100000000) {
                var a = ((nnum / 10000000).toFixed(2));
                return (a + "Crore");

            } else if (nnum > 1000000) {
                var a = ((nnum / 100000).toFixed(2));
                return (a + 'Lakh');

            } else if (nnum > 10000) {
                var a = ((nnum / 1000).toFixed(2));
                return (a + 'k');

            } else {
                return (nnum);
            }

        }

        $(window).off('scroll');
    }

})

function share(dId) {
    var donateId = dId
    console.log(donateId);
    $("#shareIt").css({ "display": "block" })
    $(".share-block").delay(500).css({ "right": "0px" })
    $("#mail").attr("href", "mailto:?subject=&body=")
    $(".socialIcon").click(function() {
        var site = $(this).attr("id");

        $.ajax({
            url: "/share",
            data: { 'url': "http://sanjivani.org/", "title": "Sanjivani", "site": site },
            type: 'POST',
            success: function(response) {
                window.open(response['link']);


            },
            error: function() {
                console.log("error");
            }
        })

    })


}
$("#close").click(function() {
    $(".share-block").css({ "right": "-100px" })
    $("#shareIt").css({ "display": "none" })

})