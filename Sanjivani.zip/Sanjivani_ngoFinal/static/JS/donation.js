// bankDetails is a global variable

async function fetchCarousel() {
    try {
        const response = await fetch("res/fake-api/carousel.json");
        const data = await response.json();
        const carouselImg = data.carouselImg;
        const carouselRoot = document.getElementById("carousel-img-root");
        const carouselIndicatorsRoot = document.getElementById(
            "carousel-indicators-root"
        );
        carouselImg.forEach((img, index) => {
            if (index === 0) {
                carouselIndicatorsRoot.innerHTML += `<li data-target="#carouselExampleIndicators" data-slide-to="${index}" class="active"></li>`;
                carouselRoot.innerHTML += `<div class="carousel-item active">
                      <img class="d-block w-100" src="${img}" alt="slide">
              </div>`;
            } else {
                carouselIndicatorsRoot.innerHTML += `<li data-target="#carouselExampleIndicators" data-slide-to="${index}"></li>`;
                carouselRoot.innerHTML += `<div class="carousel-item">
                      <img class="d-block w-100" src="${img}" alt="slide">
              </div>`;
            }
        });
    } catch (error) {
        console.log(error);
    }
}
fetchCarousel();

async function fetchAbout() {
    try {
        const response = await fetch("res/fake-api/about.json");
        const data = await response.json();
        const about = data.about;
        const aboutRoot = document.getElementById("about-root");
        aboutRoot.innerHTML = `<p>${about}</p>`;
    } catch (error) {
        console.log(error)
    }
}
fetchAbout();
async function fetchUpdates() {
    try {
        const response = await fetch("res/fake-api/updates.json");
        const data = await response.json();
        const updates = data.updates;
        const aboutRoot = document.getElementById("about-root");
        aboutRoot.innerHTML = ``;
        updates.forEach((element) => {
            aboutRoot.innerHTML += `<div class="comment-div border"><span class="comment-name pr-2">${element.date}</span><span data-toggle="modal" data-target="#updateModal" class="comment update-topic" style="cursor:pointer">${element.topic}</span></div>`;
        });
    } catch (error) {
        console.log(error)
    }
}

async function fetchComments() {
    try {
        const response = await fetch("res/fake-api/comments.json");
        const data = await response.json();
        const comments = data.comments;
        const aboutRoot = document.getElementById("about-root");
        aboutRoot.innerHTML = ``;
        comments.forEach((element) => {
            aboutRoot.innerHTML += `<div class = 'comment-div border'><span class ='comment-name'>${element.name}</span><br><span class='comment'>${element.comment}</span></div>`;
        });
    } catch (error) {
        console.log(error)
    }
}

async function fetchFund() {
    try {
        const response = await fetch("res/fake-api/fund.json");
        const data = await response.json();
        let progress = (data.raisedAmount / data.goal) * 100;
        const goalRoot = document.getElementById("goal-root");
        goalRoot.innerHTML = `<div><div class="h1 font-weight-normal">₹${data.raisedAmount}</div><div>Raised Of <span class = "h6">₹${data.goal}</span> goal</div></div><div class="progress my-3" style="height:0.6rem;background-color:rgb(213,213,213)">
          <div class="progress-bar" role="progressbar" style="width: ${progress}%;height: .6rem;background-color: rgb(71,159,206);" aria-valuenow="${progress}" aria-valuemin="0" aria-valuemax="100"></div>
        </div>`;
    } catch (error) {
        console.log(error);
    }
}
fetchFund();
async function fetchContacts() {
    try {
        const response = await fetch("res/fake-api/contacts.json");
        const data = await response.json();
        const contacts = data.contacts;
        const contactRoot = document.getElementById("contact-root");
        contacts.forEach((element) => {
            contactRoot.innerHTML += `<a href="${element.link}" class="btn text-capitalize socials-btn" style="background-color:${element.bgColor};color:${element.color}"><i class="fab fa-${element.name}" aria-hidden="true"></i>&nbsp; ${element.name}</a>`;
        });
    } catch (error) {
        console.log(error);
    }
}
fetchContacts();

async function fetchFundraisers() {
    try {
        const response = await fetch("res/fake-api/fundraiser.json");
        const data = await response.json();
        const fundraiser = data.fundraiser;
        const fundraisersRoot = document.getElementById("fundraisers-root");
        fundraiser.forEach((element) => {
            fundraisersRoot.innerHTML += `<span>${element.name}</span><br>`;
        });
        const totalSupporterRoot = document.getElementById("total-supporter-root");
        totalSupporterRoot.innerHTML = `<span class="h5">${fundraiser.length}</span> supporters`;
    } catch (error) {
        console.log(error);
    }
}
fetchFundraisers();
async function fetchTopDonors() {
    try {
        const response = await fetch("res/fake-api/topDonor.json");
        const data = await response.json();
        const topDonor = data.topDonor;
        const topDonorRoot = document.getElementById("top-donor-root");
        topDonor.forEach((element) => {
            topDonorRoot.innerHTML += `<span>${element.name}</span><br>`;
        });
    } catch (error) {
        console.log(error);
    }
}
fetchTopDonors();

$(".aboutNav .nav-item .nav-link").click(function() {
    $(".aboutNav .nav-item .nav-link").removeClass("active");
    $(this).addClass("active");
});

function donateClickFun(index) {
    $(".donate-card-option").removeClass("active");
    if (index === 0) {
        let activeClass = $(".donate-card-option")[0];
        activeClass.classList.add("active");
        $("#donation-details-root").fadeOut(300, function() {
            $(this)
                .html(
                    `<img class="col-7" style="max-width: 15rem;" src="${bankDetails[0]}" alt="">`
                )
                .fadeIn(300);
        });
    } else if (index === 1) {
        let activeClass = $(".donate-card-option")[1];
        activeClass.classList.add("active");
        $("#donation-details-root").fadeOut(300, function() {
            $(this)
                .html(
                    `<div><div><span class="h6">Account No: </span><span>${bankDetails[1].AccountNo}</span></div><div><span class="h6">IFSC Code: </span><span>${bankDetails[1].IFSCCode}</span></div></div>`
                )
                .fadeIn(300);
        });
    }
}

let bankDetails = [];
async function fetchBank() {
    try {
        const response = await fetch("res/fake-api/donation.json");
        const data = await response.json();
        const options = data.options;
        options.forEach((element, index) => {
            bankDetails.push(element.details);
            console.log(bankDetails);
            $("#donation-methods-root").append(
                `<span class="donate-card-option px-2" onclick="donateClickFun(${index})">${element.name}</span>`
            );
            if (index === 0) {
                $(".donate-card-option").addClass("active");
                $("#donation-details-root").html(
                    `<img class="col-7" style="max-width: 15rem;" src="${element.details}" alt="">`
                );
            }
        });
    } catch (error) {
        console.log(error);
    }
}
fetchBank();